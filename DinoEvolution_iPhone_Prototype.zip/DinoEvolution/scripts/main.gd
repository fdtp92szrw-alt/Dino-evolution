extends Node3D

var dino: Node3D
var enemies: Array[Node3D] = []
var xp := 0
var level := 1
var trophies := 0
var stats := {"hp":100, "attack":10, "speed":5.0, "armor":0}
var mutation := {"head":"Small Jaw", "legs":"Runner Legs", "tail":"Balanced Tail", "arms":"Claws", "skin":"Amber"}
var xp_next := 100
var status_label: Label
var stats_label: Label
var trophy_label: Label
var mutation_label: Label
var message_label: Label
var joy_center := Vector2.ZERO
var joy_active := false
var joy_vector := Vector2.ZERO
var attack_pressed := false

func _ready():
    _build_world()
    _build_dino()
    _build_ui()
    _spawn_enemy(Vector3(7,0,2), "Raptor")
    _spawn_enemy(Vector3(-6,0,-3), "Triceratops")
    _spawn_enemy(Vector3(3,0,-8), "Compy")
    _update_ui()

func _build_world():
    var env = WorldEnvironment.new()
    var e = Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color("#87b96b")
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("#ffffff")
    e.ambient_light_energy = 0.7
    env.environment = e
    add_child(env)
    var light = DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-55,-25,0)
    light.light_energy = 1.2
    add_child(light)
    var ground = MeshInstance3D.new()
    var box = BoxMesh.new(); box.size = Vector3(40,0.2,40)
    ground.mesh = box
    var mat = StandardMaterial3D.new(); mat.albedo_color = Color("#6e9f52")
    ground.material_override = mat
    ground.position.y = -0.1
    add_child(ground)
    var cam = Camera3D.new(); cam.position = Vector3(0,12,16); cam.rotation_degrees = Vector3(-32,0,0); cam.current=true
    add_child(cam)

func _build_dino():
    dino = Node3D.new(); dino.name = "PlayerDino"; add_child(dino)
    dino.position = Vector3(0,0,0)
    _add_part(dino, Vector3(0,1.4,0), Vector3(2.8,1.4,1.3), Color("#d98c35"))
    _add_part(dino, Vector3(1.65,2.1,0), Vector3(1.2,1.0,1.0), Color("#d98c35"))
    _add_part(dino, Vector3(2.25,2.15,0), Vector3(0.8,0.5,0.8), Color("#b85d2c"))
    _add_part(dino, Vector3(-1.9,1.4,0), Vector3(2.2,0.35,0.45), Color("#c77430"))
    for x in [-0.9,0.9]:
        _add_part(dino, Vector3(x,0.45,0.45), Vector3(0.5,1.0,0.55), Color("#b9662e"))
        _add_part(dino, Vector3(x,0.45,-0.45), Vector3(0.5,1.0,0.55), Color("#b9662e"))
    for z in [-0.55,0.0,0.55]:
        _add_part(dino, Vector3(0.1,2.15,z), Vector3(0.3,0.7,0.25), Color("#5e3a28"))

func _add_part(parent, pos:Vector3, size:Vector3, color:Color):
    var m=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; m.mesh=mesh
    var mat=StandardMaterial3D.new(); mat.albedo_color=color; m.material_override=mat; m.position=pos; parent.add_child(m)

func _spawn_enemy(pos:Vector3, kind:String):
    var e=Node3D.new(); e.name=kind; add_child(e); e.position=pos
    var color=Color("#8f4b3c") if kind=="Raptor" else Color("#6f7d4c")
    _add_part(e,Vector3(0,1,0),Vector3(2.2,1.1,1.1),color)
    _add_part(e,Vector3(1.3,1.6,0),Vector3(0.9,0.8,0.8),color)
    _add_part(e,Vector3(-1.4,1,0),Vector3(1.6,0.25,0.3),color)
    enemies.append(e)

func _build_ui():
    var layer=CanvasLayer.new(); add_child(layer)
    var panel=ColorRect.new(); panel.position=Vector2(20,20); panel.size=Vector2(390,165); panel.color=Color(0.05,0.08,0.06,0.82); layer.add_child(panel)
    status_label=Label.new(); status_label.position=Vector2(40,30); status_label.add_theme_font_size_override("font_size",24); layer.add_child(status_label)
    stats_label=Label.new(); stats_label.position=Vector2(40,70); stats_label.add_theme_font_size_override("font_size",18); layer.add_child(stats_label)
    trophy_label=Label.new(); trophy_label.position=Vector2(40,125); trophy_label.add_theme_font_size_override("font_size",18); layer.add_child(trophy_label)
    mutation_label=Label.new(); mutation_label.position=Vector2(880,30); mutation_label.size=Vector2(370,160); mutation_label.add_theme_font_size_override("font_size",18); layer.add_child(mutation_label)
    message_label=Label.new(); message_label.position=Vector2(430,610); message_label.size=Vector2(420,50); message_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; message_label.add_theme_font_size_override("font_size",20); layer.add_child(message_label)
    var hint=Label.new(); hint.text="WASD / стрелки — движение   ПРОБЕЛ — атака\nНа iPhone: используй экранные кнопки"; hint.position=Vector2(20,650); hint.add_theme_font_size_override("font_size",16); layer.add_child(hint)
    _add_touch_button(layer, Vector2(70,500), "◀", "left")
    _add_touch_button(layer, Vector2(150,500), "▶", "right")
    _add_touch_button(layer, Vector2(110,440), "▲", "up")
    _add_touch_button(layer, Vector2(110,560), "▼", "down")
    _add_touch_button(layer, Vector2(1060,540), "ATTACK", "attack")
    _add_touch_button(layer, Vector2(1060,450), "MUTATE", "mutate")

func _add_touch_button(layer, pos:Vector2, text:String, action:String):
    var b=Button.new(); b.text=text; b.position=pos; b.size=Vector2(90,70); b.add_theme_font_size_override("font_size",16); layer.add_child(b)
    if action=="attack": b.pressed.connect(_attack)
    elif action=="mutate": b.pressed.connect(_mutate)
    else:
        b.button_down.connect(func(): joy_vector = {"left":Vector2(-1,0),"right":Vector2(1,0),"up":Vector2(0,-1),"down":Vector2(0,1)}[action])
        b.button_up.connect(func(): joy_vector=Vector2.ZERO)

func _process(delta):
    if not dino: return
    var v=Vector2(Input.get_axis("move_left","move_right"),Input.get_axis("move_up","move_down"))
    if v.length()<0.1: v=joy_vector
    if v.length()>0:
        v=v.normalized(); dino.position.x += v.x*stats.speed*delta; dino.position.z += v.y*stats.speed*delta
        dino.rotation.y=lerp_angle(dino.rotation.y,atan2(v.x,v.y),delta*8.0)
    if Input.is_action_just_pressed("attack"): _attack()
    for e in enemies:
        if is_instance_valid(e) and dino.position.distance_to(e.position)<2.7:
            e.position += (e.position-dino.position).normalized()*delta*1.5

func _attack():
    for e in enemies.duplicate():
        if is_instance_valid(e) and dino.position.distance_to(e.position)<4.0:
            e.queue_free(); enemies.erase(e); _gain_xp(45); trophies += 1
            message_label.text="Трофей добыт! +45 XP"
            await get_tree().create_timer(0.7).timeout
            _spawn_enemy(Vector3(randf_range(-10,10),0,randf_range(-10,10)),"Raptor")
            _update_ui(); return
    message_label.text="Слишком далеко! Подойди ближе."

func _gain_xp(amount:int):
    xp += amount
    while xp>=xp_next:
        xp-=xp_next; level+=1; xp_next=int(xp_next*1.25); stats.attack+=2; stats.hp+=10; stats.speed+=0.25
        message_label.text="LEVEL UP! Динозавр стал сильнее!"

func _mutate():
    var choices=["Bone Crusher","Raptor Claws","Heavy Tail","Titan Legs","Spiked Hide"]
    var c=choices[randi()%choices.size()]
    if c=="Bone Crusher": stats.attack+=5; mutation.head=c
    elif c=="Raptor Claws": stats.attack+=3; mutation.arms=c
    elif c=="Heavy Tail": stats.hp+=20; mutation.tail=c
    elif c=="Titan Legs": stats.speed+=0.7; mutation.legs=c
    else: stats.armor+=3; mutation.skin=c
    message_label.text="Мутация: "+c
    _update_ui()

func _update_ui():
    status_label.text="🦖 Уровень %d   XP %d / %d" % [level,xp,xp_next]
    stats_label.text="❤️ %d   ⚔ %d   🏃 %.1f   🛡 %d" % [stats.hp,stats.attack,stats.speed,stats.armor]
    trophy_label.text="🏆 Трофеи: %d" % trophies
    mutation_label.text="🧬 ЭВОЛЮЦИЯ\nГолова: %s\nПередние конечности: %s\nНоги: %s\nХвост: %s\nКожа: %s" % [mutation.head,mutation.arms,mutation.legs,mutation.tail,mutation.skin]
